package com.example.basicprimitives;

import com.example.basicprimitives.R;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Path.FillType;
import android.graphics.Point;
import android.graphics.RectF;
import android.view.View;




public class BasicPrimitives extends View{
	
	
	Paint paint = new Paint();
	
	
	public BasicPrimitives(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);
		
		paint.setColor(getResources().getColor(R.color.Teal));
		paint.setTextSize(30);
		
		canvas.drawText("Graphical Primitive",50,50,paint);
		paint.setColor(Color.BLACK);
		paint.setStrokeWidth(8);
		canvas.drawPoint(55,90,paint);
		canvas.drawText(" - Point",58,95,paint);
		canvas.drawText("Drawing Line:",60,150,paint);
		paint.setColor(Color.BLACK);
		canvas.drawLine(60, 180, 210, 180, paint);
		
		canvas.drawText("Square",300,260,paint);
		Paint myPaint = new Paint();
		myPaint.setColor(Color.rgb(0, 0, 0));
		myPaint.setStrokeWidth(3);
		myPaint.setStyle(Paint.Style.STROKE);
		canvas.drawRect(60, 210, 160, 310, myPaint);
		canvas.drawRect(65, 215, 155, 305, myPaint);
		myPaint.setColor(getResources().getColor(R.color.BlueViolet));
		myPaint.setStyle(Paint.Style.FILL);
		canvas.drawRect(80, 230, 140, 290, myPaint);
		
		canvas.drawText("Circle",300,400,paint);
		canvas.drawCircle(110, 400, 35, myPaint);
		myPaint.setStyle(Paint.Style.STROKE);
		myPaint.setColor(Color.rgb(0, 0, 0));
		canvas.drawCircle(110, 400, 60, myPaint);
		canvas.drawCircle(110, 400, 65, myPaint);
		
		canvas.drawText("Rounded Rectangle",280,550,paint);
		canvas.drawRoundRect(new RectF(60, 500, 260, 600), 25, 25, myPaint);
		canvas.drawRoundRect(new RectF(65, 505, 255, 595), 23, 23, myPaint);
		myPaint.setStyle(Paint.Style.FILL);
		myPaint.setColor(getResources().getColor(R.color.BlueViolet));
		canvas.drawRoundRect(new RectF(75, 515, 245, 585), 20, 20, myPaint);
		
		//paint.setColor(android.graphics.Color.BLACK);
	    //canvas.drawPaint(paint);

	    paint.setStrokeWidth(4);
	    paint.setColor(android.graphics.Color.RED);
	    paint.setStyle(Paint.Style.STROKE);
	    paint.setAntiAlias(true);

	    Point a = new Point(60, 650);
	    Point b = new Point(60, 800);
	    Point c = new Point(150, 725);

	    Path path = new Path();
	    path.setFillType(FillType.EVEN_ODD);
	    path.moveTo(a.x, a.y);
	    path.lineTo(b.x, b.y);
	    path.moveTo(b.x, b.y);
	    path.lineTo(c.x, c.y);
	    path.moveTo(c.x, c.y);
	    path.lineTo(a.x, a.y);
	    path.close();

	    canvas.drawPath(path, paint);
	/*	
		Paint myPaint = new Paint();
		myPaint.setColor(Color.rgb(0, 0, 0));
		myPaint.setStrokeWidth(10);
		canvas.drawRect(100, 100, 200, 200, myPaint);
		
		paint.setColor(Color.BLUE);
		paint.setStrokeWidth(0);
		canvas.drawRect(100, 100, 300, 300, paint);
		paint.setColor(Color.GREEN);
		canvas.drawCircle(200, 200, 75, paint);
		paint.setColor(Color.BLACK);
		canvas.drawLine(100, 200, 300, 200, paint);
	*/
		
	}
	
	
 }



