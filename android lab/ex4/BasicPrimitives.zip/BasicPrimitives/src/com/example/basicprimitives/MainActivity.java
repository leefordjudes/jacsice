package com.example.basicprimitives;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;


public class MainActivity extends Activity implements OnTouchListener {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.activity_main);
		
		BasicPrimitives drawView = new BasicPrimitives(this);
		setContentView(drawView);
		drawView.setOnTouchListener(this);
		
		
	}
	
	public boolean onTouch(View v, MotionEvent event) {
        // TODO Auto-generated method stub
        int action = event.getAction();
        switch(action){
            case MotionEvent.ACTION_DOWN:
            startActivity(new Intent(this,ThirdActivity.class));
            finish();
            break;
        }
        return true;
    }
	
}
