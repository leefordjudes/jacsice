package in.jacsice.android.simplecalculator;

//import in.jacsice.android.simplecalculator.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
//import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	  EditText etNum1;
	  EditText etNum2;

	  Button btnAdd;
	  Button btnSub;
	  Button btnMul;
	  Button btnDiv;

	  TextView tvResult;

	  String oper = "";
	  
	  Toast msg;
	  Intent calc1,calc2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// find the elements
	    etNum1 = (EditText) findViewById(R.id.etNum1);
	    etNum2 = (EditText) findViewById(R.id.etNum2);

	    btnAdd = (Button) findViewById(R.id.btnAdd);
	    btnSub = (Button) findViewById(R.id.btnSub);
	    btnMul = (Button) findViewById(R.id.btnMul);
	    btnDiv = (Button) findViewById(R.id.btnDiv);

	    tvResult = (TextView) findViewById(R.id.tvResult);

	    // set a listener
	    btnAdd.setOnClickListener((OnClickListener) this);
	    btnSub.setOnClickListener(this);
	    btnMul.setOnClickListener(this);
	    btnDiv.setOnClickListener(this);

	  }

	  @Override
	  public void onClick(View v) {
	    // TODO Auto-generated method stub
	    float num1 = 0;
	    float num2 = 0;
	    float result = 0;

	    // check if the fields are empty
	   // if (TextUtils.isEmpty(etNum1.getText().toString()) || TextUtils.isEmpty(etNum2.getText().toString())) 
	   // {return;}
	    //String n = "N1:"+etNum1.getText().toString() +"\n N2:"+ etNum2.getText().toString();
	    //Toast.makeText(MainActivity.this, n, Toast.LENGTH_LONG).show();

	    
	    if(etNum1.getText().toString().equals("") || etNum1.getText().toString().equals(null))
        {
	    	msg = Toast.makeText(MainActivity.this, "Number1 is empty!", Toast.LENGTH_SHORT);
	    	msg.setGravity(Gravity.CENTER|Gravity.CENTER_HORIZONTAL, 0, -100);
			msg.show();
	    	etNum1.setFocusable(true);
	    	etNum1.setCursorVisible(true);
	    	etNum1.requestFocus();
	    	return;
        
        }
	    
	    if(etNum2.getText().toString().equals("") || etNum2.getText().toString().equals(null))
        {
	    	msg = Toast.makeText(MainActivity.this, "Number2 is empty!", Toast.LENGTH_SHORT);
	    	msg.setGravity(Gravity.CENTER|Gravity.CENTER_HORIZONTAL, 0, -200);
			msg.show();
	        etNum2.setFocusable(true);
	    	etNum2.setCursorVisible(true);
	    	etNum2.requestFocus();
	    	return;
	    }

	    // read EditText and fill variables with numbers
	    num1 = Float.parseFloat(etNum1.getText().toString());
	    num2 = Float.parseFloat(etNum2.getText().toString());

	    // defines the button that has been clicked and performs the corresponding operation
	    // write operation into oper, we will use it later for output
	    switch (v.getId()) {
	    case R.id.btnAdd:
	      oper = "+";
	      result = num1 + num2;
	      break;
	    case R.id.btnSub:
	      oper = "-";
	      result = num1 - num2;
	      break;
	    case R.id.btnMul:
	      oper = "*";
	      result = num1 * num2;
	      break;
	    case R.id.btnDiv:
	      oper = "/";
	      result = num1 / num2;
	      break;
	    default:
	      break;
	    }

	    // form the output line
	    tvResult.setText(num1 + " " + oper + " " + num2 + " = " + result);
	    
	    
	  }
		
	public void CalculatorOne(View v){
		msg = Toast.makeText(MainActivity.this, "Calculator One!", Toast.LENGTH_SHORT);
    	msg.setGravity(Gravity.CENTER|Gravity.CENTER_HORIZONTAL, 0, 100);
		msg.show();
		
		calc1 = new Intent(MainActivity.this,Calc1Activity.class);
		startActivity(calc1);
		//finish();  //  To unload current activity
	}
	
	public void CalculatorTwo(View v){
		msg = Toast.makeText(MainActivity.this, "Calculator Two!", Toast.LENGTH_SHORT);
    	msg.setGravity(Gravity.CENTER|Gravity.CENTER_HORIZONTAL, 0, 200);
		msg.show();
		
		calc2 = new Intent(MainActivity.this,Calc2Activity.class);
		startActivity(calc2);
		finish();
		//onBackPressed();  // go to previous activity
	}
	
	public void ClearText(View v){
		etNum1.setText("");
		etNum2.setText("");
		tvResult.setText("");
		etNum1.requestFocus();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
