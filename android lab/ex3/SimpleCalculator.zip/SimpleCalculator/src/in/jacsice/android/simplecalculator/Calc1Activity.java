package in.jacsice.android.simplecalculator;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;


public class Calc1Activity extends Activity implements OnClickListener {
	
	private float num1=0,num2=0,res=0;
	private String num1str="0",num2str="0",resstr="0",scrstr="0",opstr="";
	private EditText txtscr;
	private Button b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,bd,beq;  //bc
	private Button badd,bsub,bmul,bdiv;
	private int curpos; 
	private String inDigit;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_calc1);
		
		txtscr = (EditText) findViewById(R.id.txtScreen);
		txtscr.setText("0");
		curpos = txtscr.length();
		txtscr.setSelection(curpos);
		
		b0 = (Button) findViewById(R.id.btn0);
		b1 = (Button) findViewById(R.id.btn1);
		b2 = (Button) findViewById(R.id.btn2);
		b3 = (Button) findViewById(R.id.btn3);
		b4 = (Button) findViewById(R.id.btn4);
		b5 = (Button) findViewById(R.id.btn5);
		b6 = (Button) findViewById(R.id.btn6);
		b7 = (Button) findViewById(R.id.btn7);
		b8 = (Button) findViewById(R.id.btn8);
		b9 = (Button) findViewById(R.id.btn9);
		//bc = (Button) findViewById(R.id.btnClear);
		bd = (Button) findViewById(R.id.btnDot);
		beq = (Button) findViewById(R.id.btnEquals);
		badd = (Button) findViewById(R.id.btnAdd);
		bsub = (Button) findViewById(R.id.btnSubtract);
		bmul = (Button) findViewById(R.id.btnMultiply);
		bdiv = (Button) findViewById(R.id.btnDivide);
		
		b0.setOnClickListener(this);
		b1.setOnClickListener(this);
		b2.setOnClickListener(this);
		b3.setOnClickListener(this);
		b4.setOnClickListener(this);
		b5.setOnClickListener(this);
		b6.setOnClickListener(this);
		b7.setOnClickListener(this);
		b8.setOnClickListener(this);
		b9.setOnClickListener(this);
		//bc.setOnClickListener(this);
		bd.setOnClickListener(this);
		beq.setOnClickListener(this);
		badd.setOnClickListener(this);
		bsub.setOnClickListener(this);
		bmul.setOnClickListener(this);
		bdiv.setOnClickListener(this);
	}
	
	public void onClick(View v) {
		
		
		
		switch (v.getId()) {
		case R.id.btn0:
		case R.id.btn1:
		case R.id.btn2:
		case R.id.btn3:
		case R.id.btn4:
		case R.id.btn5:
		case R.id.btn6:
		case R.id.btn7:
		case R.id.btn8:
		case R.id.btn9:
			inDigit = ((Button) v).getText().toString();
			if(scrstr.equals("0"))
				{scrstr = inDigit;}
			else
				{scrstr += inDigit;}
			txtscr.setText(scrstr);
			curpos = txtscr.length();
			txtscr.setSelection(curpos);
			inDigit="";
			break;
			
		case R.id.btnDot:
			inDigit = ((Button) v).getText().toString();
			if(scrstr.equals("0"))
			{	
				scrstr = "0"+inDigit;		
			}
			else if(scrstr.contains(inDigit))
			{	
				return;		
			}
			else
			{scrstr += inDigit;}
			txtscr.setText(scrstr);
			curpos = txtscr.length();
			txtscr.setSelection(curpos);
			inDigit="";
			break;
		
		case R.id.btnEquals:
			if(!num1str.equals("0") && resstr.equals("0"))
			{
				num2str=txtscr.getText().toString();
				calculate();
			}
			else
			{
				num1str=txtscr.getText().toString();
				resstr = num1str;
			 }
			
		/*	msg = Toast.makeText(Calc1Activity.this, "num1: "+num1str+"\nnum2: "+num2str+"\nOperator: "+opstr+"\nres: "+resstr, Toast.LENGTH_SHORT);
	    	msg.setGravity(Gravity.CENTER|Gravity.CENTER_HORIZONTAL, 0, -100);
			msg.show(); 
		*/
			String tempstr = resstr;
			Calc1ClearAll(v);
			txtscr.setText(tempstr);
			curpos = txtscr.length();
			txtscr.setSelection(curpos);
			break;
		
		case R.id.btnAdd:
		case R.id.btnSubtract:
		case R.id.btnMultiply:
		case R.id.btnDivide:
				if(num1str.equals("0") && resstr.equals("0"))
				{
					num1str=txtscr.getText().toString();
				}
				else if(!num1str.equals("0") && !resstr.equals("0"))
				{
					num1str = resstr;
					resstr="0";
				}
				opstr=((Button) v).getText().toString();
				txtscr.setText("0");
				scrstr="0";
				curpos = txtscr.length();
				txtscr.setSelection(curpos);
			break;
			
		
			
		}
	}
	public void calculate()
	{
		num1=Float.parseFloat(num1str);
		num2=Float.parseFloat(num2str);
		
		switch(opstr){
			case "+":
				res=num1+num2;
				break;
			case "-":
				res=num1-num2;
				break;
			case "*":
				res=num1*num2;
				break;
			case "/":
				res=num1/num2;
				break;
		}
		resstr=String.valueOf(res);
		txtscr.setText(resstr);
		
	}
	public void goBack(View v){
		onBackPressed();   //  call the previous activity
		finish();   // unload the current activity
	}
	
	public void Calc1ClearAll(View v){
		//clear all numbers and results and operators
		scrstr="0";
		txtscr = (EditText) findViewById(R.id.txtScreen);
		txtscr.setText("0");
		curpos = txtscr.length();
		txtscr.setSelection(curpos);
		num1str="0";
		num2str="0";
		resstr="0";
		opstr="";
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.calc1, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
